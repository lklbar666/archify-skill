# Archify 使用示例

以下示例全部可直接复制使用，基于 Archify v3.2.0。

```plaintext
=== 示例1：基础架构图（从描述生成） ===

用户输入：
Use Archify to diagram a web request: Browser calls the API,
the API checks Redis, and a cache miss queries PostgreSQL and fills the cache.

Agent执行：
1. 创建 .archify/architecture-web-cache-20261023-160000/ 目录
2. 编写 candidate.json（architecture类型，包含Browser/API/Redis/PostgreSQL节点及关系）
3. 运行：node bin/archify.mjs finalize architecture candidate.json output.html --quality showcase --json
4. 交付 output.html（独立HTML，支持深色/浅色主题、交互探索、导出PNG/SVG/WebM）


=== 示例2：从真实代码库生成带源码证据的架构图 ===

用户输入：
Analyze this repository, then use archify to create a high-level runtime architecture diagram.
Show 8-12 core components, one primary path, external dependencies, and trust boundaries.

Agent执行：
1. 阅读 references/repository-authoring.md
2. 扫描代码库，识别核心组件和运行时关系
3. 编写带 source 证据的 candidate.json（节点标记 SRC n，关联Git提交和文件行号）
4. 运行：node bin/archify.mjs finalize architecture candidate.json output.html --repo-root . --quality showcase --json
5. 图中每个节点可点击打开源码卡片，定位到具体文件和行号


=== 示例3：工作流图（CI/CD流程） ===

用户输入：
Use Archify to draw our CI/CD workflow: developer pushes code, GitHub Actions runs tests,
on success builds Docker image, pushes to registry, then ArgoCD deploys to staging,
manual approval triggers production deployment.

Agent执行：
1. 选择 workflow 类型
2. 编写 candidate.json（参与者：Developer/GitHub Actions/Registry/ArgoCD/Staging/Production，含审批分支）
3. 运行：node bin/archify.mjs finalize workflow candidate.json cicd.html --quality showcase --json
4. 支持泳道视图、高亮特定路径、动画播放


=== 示例4：时序图（API调用链） ===

用户输入：
Use Archify to show the sequence for user login: client sends credentials,
API validates with DB, generates JWT, returns token, client stores and uses for subsequent requests.

Agent执行：
1. 选择 sequence 类型
2. 编写 candidate.json（参与者：Client/API/DB，消息：POST /login/SELECT/INSERT/JWT生成/返回）
3. 运行：node bin/archify.mjs finalize sequence candidate.json login-sequence.html --quality showcase --json


=== 示例5：ERD数据库关系图 ===

用户输入：
Use Archify to create an ERD for an order management system with customers, orders,
order_items, products, payments, and inventory. Show every column with type and keys.

Agent执行：
1. 选择 erd 类型
2. 编写 candidate.json（6张表，每表含全部列名/SQL类型/主键/外键/唯一键，按领域分组）
3. 表优先布局：每个领域一个tag，占据网格矩形区域
4. 运行：node bin/archify.mjs finalize erd candidate.json order-erd.html --quality standard --json
5. 超过8表或50字段时先用standard密度，布局可读后再升级showcase


=== 示例6：从Mermaid转换 ===

用户输入：
Convert this Mermaid to Archify:
sequenceDiagram
    participant User
    participant Server
    participant DB
    User->>Server: Request
    Server->>DB: Query
    DB-->>Server: Result
    Server-->>User: Response

Agent执行：
1. 读取Mermaid获取拓扑和语义（不机械渲染Mermaid样式）
2. sequenceDiagram → sequence 类型
3. 参与者转为 semantic participants，箭头转为 messages
4. 编写全新的 Archify JSON candidate
5. 运行 finalize 交付

Mermaid映射规则：
- flowchart/graph → workflow（或 architecture 用于组件图）
- sequenceDiagram → sequence
- stateDiagram → lifecycle
- erDiagram → erd
- classDiagram → class


=== 示例7：一页式解释页面（Explainer） ===

用户输入：
Use Archify to answer as one page: our API's P99 went from 80ms to 600ms
while the mean barely moved. What is the likely cause, and how should we investigate?

Agent执行：
1. 选择 explainer 模式
2. 阅读 references/explainer-authoring.md
3. 编写 candidate.archify.md（结论先行 + 每个问题一个面板 + 表格/步骤/图表/代码）
4. 运行：node bin/archify.mjs finalize explainer candidate.archify.md p99-analysis.html --json
5. 交付单文件HTML，支持4种样式、深浅主题、导出长图/PDF


=== 示例8：不确定图表类型时用guide命令 ===

用户输入：
Show an API request with Redis cache miss and fallback to PostgreSQL.

Agent执行：
运行：node bin/archify.mjs guide "Show an API request with Redis cache miss" --json
返回推荐类型（sequence）及结构建议，然后按推荐类型编写candidate。


=== 示例9：迭代修改已有图表 ===

用户输入（在已有架构图后）：
Add authentication, highlight the cache-miss path, switch to the light theme.

Agent执行：
1. 在现有 candidate.json 基础上修改：添加Auth节点和关系
2. 设置 meta.theme = "light"
3. 标记 cache-miss 路径为高亮
4. 重新运行 finalize（使用新的 --out-dir 避免覆盖已有浏览器证据）
5. 交付更新后的HTML


=== 示例10：时间线图（事件复盘） ===

用户输入：
Use Archify to create a timeline of the production incident:
14:02 alert fired, 14:05 on-call acknowledged, 14:12 root cause identified,
14:20 fix deployed, 14:35 metrics recovered, 15:00 post-mortem scheduled.

Agent执行：
1. 选择 timeline 类型
2. 编写 candidate.json（带时区的时间戳、事件、来源泳道，标注是观测值还是说明性值）
3. 运行：node bin/archify.mjs finalize timeline candidate.json incident.html --quality showcase --json


=== 常用命令速查 ===

# 诊断环境
node bin/archify.mjs doctor

# 生成演示文件
node bin/archify.mjs demo ./output-dir

# 场景引导（JSON输出）
node bin/archify.mjs guide "your scenario" --json

# 最终交付（所有类型通用）
node bin/archify.mjs finalize <type> <candidate.json> <output.html> --quality showcase --json

# 带代码库证据
node bin/archify.mjs finalize architecture candidate.json output.html --repo-root . --quality showcase --json

# 支持的10种类型：
# architecture, workflow, sequence, dataflow, lifecycle, erd, class, tree, timeline, waterfall
```
